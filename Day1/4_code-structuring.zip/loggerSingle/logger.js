class Logger {
    log(message) {
        console.log(`${message}, logged using Logger Class log method.`);
    }
}

module.exports = Logger;