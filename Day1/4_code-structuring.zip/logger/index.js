console.log("Logged from Logger folder index.js File");
