console.log("Logged from Logger folder myLogger.js File");
