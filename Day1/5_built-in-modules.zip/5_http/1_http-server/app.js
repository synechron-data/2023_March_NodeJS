// const http = require('http');

// const server = http.createServer((req, res) => {
//     // console.log(req.url);
//     // console.log(req.headers);
//     // res.end("Response from Node HTTP Server");

//     // res.setHeader("content-type", "text/html");
//     // res.setHeader("content-type", "text/plain");
//     // res.setHeader("content-type", "application/json");
//     res.setHeader("content-type", "application/pdf");

//     res.write("<h1>Response from Node HTTP Server</h1>");
//     res.end();
// });

// server.listen(3000);

// function onError(err) {
//     console.log(err);
// }

// function onListening() {
//     var address = server.address();
//     console.log(`Server started on port: ${address.port}`);
// }

// server.on('error', onError);
// server.on('listening', onListening);

// ---------------------------------------------

const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    fs.readFile('./index.html', 'utf8', (err, htmlContent) => {
        if (err) {
            res.setHeader("content-type", "text/plain");
            res.statusCode = 404;
            res.end("Page not Found...");
        } else {
            res.setHeader("content-type", "text/html");
            res.write(htmlContent);
            res.end();
        }
    });
});

server.listen(3000);

function onError(err) {
    console.log(err);
}

function onListening() {
    var address = server.address();
    console.log(`Server started on port: ${address.port}`);
}

server.on('error', onError);
server.on('listening', onListening);