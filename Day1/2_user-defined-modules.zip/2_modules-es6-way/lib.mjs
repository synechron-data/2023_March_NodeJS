class Employee {
    constructor(name) {
        this._name = name;
    }

    setName(value) {
        this._name = value;
    }

    getName() {
        return this._name;
    }
}

export default Employee;