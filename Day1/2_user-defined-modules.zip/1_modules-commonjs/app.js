// Import an entire module for side effects only, without importing anything. 
// This runs the module's global code, but doesn't actually import any values.
// require('./lib.js');

// const lib = require('./lib.js');
// // console.log(lib);
// console.log(lib.firstname);
// console.log(lib.lastname);
// console.log(lib.hello("Hi from App"));

// Load and instantiate the Employee Object  
// let e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Ramakant");
// console.log(e1.getName());

// --------------- Object Destructuring
const { Employee } = require('./lib.js');

let e1 = new Employee("Manish");
console.log(e1.getName());
e1.setName("Ramakant");
console.log(e1.getName());

var obj1 = { id: 1, name: "Manish", city: "Pune", state: "MH" };

// ECMASCRIPT 2018 - Object REST & Spread
var obj2 = { ...obj1 };     // Object Spread
var { id, name, ...address } = obj1;

// LIVESCRIPT (NetScape)
// VBSCRIPT (IE - Microsoft)  - VB (Server)

// SUN MS + NetSCAPE (JAVA - JAVASCRIPT) - ECMA
// JSCRIPT / VBSCRIPT - ECMASCRIPT - Microsoft

// IE - CHAKRA
// CH - V8
// FF - SPIDER MONKEY